# Pitch scripts: Physics-informed ML for cross-surface droplet impact

International Conference on Interfacial Phenomena in Droplets, IISc Bengaluru, 5–7 Oct 2026. Author: Parth Sharma (Thapar Institute).
Final model: Gaussian process on ln Re, ln We, ln D₀, φ, V_tex.
Numbers match the A0 landscape poster of 28 Sept 2026 and the paper (claude/research_paper_v2.md). Re-checked against the result files on 24 Sept 2026.
Data: public dataset of Može et al., *Data in Brief* 61 (2025) 111697. The experiments are theirs; the surface-held-out evaluation and the models are ours.

## 30 seconds (walk-up hook)
Droplet-impact models are usually tested on the same surfaces they were trained on. We asked a harder question: can a model predict how far a droplet spreads on a surface it has never seen?
We describe each laser-textured surface by its smooth-plateau fraction φ, computed from track widths read off SEM images, and feed it to a Gaussian process with the Reynolds and Weber numbers.
On an unseen textured surface it predicts β_max to within 0.040, 29% better than XGBoost. On a smooth plate it never trained on, it is off by 1.9% on average. And it tells you when not to trust it.

## 1 minute (someone stops and asks "what is this?")
The data is a public set from Ljubljana: about 1,500 impacts on 12 laser-textured aluminium surfaces, water to 91% glycerol, plus 125 impacts on a smooth plate. We never used the smooth plate to train or choose a model.
Most papers, including the original ML study on this data, split rows at random, so every surface is in training. We hold out one whole surface at a time. That is the test we pick models on.
The key idea is the surface description. A smooth plate has no channel spacing or depth, so encoding it with made-up values moved its error by up to 0.022. Instead we estimate track widths from SEM (about 45 µm deep, 30 µm shallow) and compute φ, the fraction of smooth plateau. The smooth plate is simply φ = 1.
We compared 13 models. A Gaussian process wins: 0.040 on unseen surfaces and 1.9% error on the smooth plate. Putting a scaling law underneath it as a physics backbone did not give a significant gain, so we kept it simple.
Its 90% intervals hold 90% of the time on unseen textured surfaces, but only 62% on the smooth plate. The misses cluster in the thin fluids: water and 20% glycerol. That is the honest limit: wettability changes and no input captures it.

## 3 minutes (full walk-through, point at the poster)
Panel numbers refer to the A0 landscape poster of 28 Sept 2026. Panel 1 and the key takeaways are in the left sidebar; panels 2–10 run down the three columns.
1. **Question (panel 1).** Surface design needs predictions *before* a surface is made. So the test is a surface the model has never seen, not a random split. The data: 1,498 textured impacts and 125 smooth-plate impacts from Može et al. (2025), We 8–119, Re 9–4,435, water to 91% glycerol.
2. **Reading the surface (panel 2).** SEM shows rough laser tracks and smooth plateaus that look like the smooth plate. From the images we get track widths of about 45 µm (deep) and 30 µm (shallow), one value per depth class. From those we compute φ and V_tex for every surface; the smooth plate is simply φ = 1, V_tex = 0. With invented spacing/depth codes, its error moved by up to 0.022; with φ, ±10 µm in track width moves it by at most 0.005.
3. **From SEM image to prediction (panel 3).** A small CNN reads three SEM views of a surface it never saw and estimates φ and V_tex. The GP on those gets 0.038 against 0.040, better on 8 of 12 surfaces but not significant. It reads the smooth plate as φ ≈ 0.71, because no training surface is smoother than 0.93.
4. **Physics inputs (panel 4).** We recompute Re and We, and they match the dataset to 5×10⁻⁷. Oh is a function of Re and We, so it adds nothing. Laan's scaling law with its published constant gives R² = 0.71 here, because it was derived on wettable surfaces.
5. **Evaluation (panel 5).** Each condition was repeated five times, so random splits leak near-identical twins. We use grouped CV and leave-one-surface-out (the selection criterion). The smooth plate is held out and never used to train or choose a model. A change is accepted only if its 95% interval, from resampling whole surfaces, excludes zero.
6. **Models (panel 6).** 13 learners on the same inputs. The GP is best on unseen surfaces at 0.040 (1.1% mean error), against 0.056 for XGBoost.
7. **What did not help (panel 7).** A Laan-law backbone, other kernels, nested selection and the CNN descriptors each change the error by under 0.002. Only XGBoost is significantly different, and it is worse. So the plain GP stays.
8. **Trust (panel 8).** On unseen surfaces 90.1% of impacts fall inside the 90% interval, but not evenly: 76% for water, 98% for 91% glycerol. A thin fluid is more sensitive to the surface, so one noise level is too narrow for it. The OOD check flags D50 and S50, the hardest surfaces.
9. **Surface by surface (panel 9).** D50, at the edge of the φ range, is the hardest surface for every learner. The texture inputs cut its error from 0.091 to 0.059, but they hurt on S50 and D200. With 12 surfaces, their benefit is a hint, not proof.
10. **Smooth plate (panel 10).** RMSE 0.059, mean error 1.9%, but only 62% inside the interval. The misses sit at high We and in water, 20% and 60% glycerol; at high We the model over-predicts, because textured surfaces spread further. The smooth plate is hydrophobic and the textures are superhydrophobic, so wettability is the missing input. Our hypothesis: less friction over the trapped air layer on the textures.
11. **Key takeaways (left sidebar).** Judge droplet models on unseen surfaces, describe surfaces with quantities every surface has, and say on the tool where the model stops being trustworthy.

## Live demo (≈60 s, laptop next to the poster)
Start it before the session: `python -m droplet.serve --port 8000`, then open http://127.0.0.1:8000. It works offline once installed.
1. **01 Predict & compare.** Pick water, D200, 2.5 mm, 1.5 m/s: β_max ≈ 2.86, 90% band 2.81–2.91.
2. Push the velocity outside the measured 0.48–1.71 m/s. The reliability status changes to extrapolation and gives the reasons.
3. Switch the surface to **REF-H**. The smooth-surface warning appears: historical interval undercoverage, wettability not modelled.
4. Under "Same impact. Five models.", show that all five trained models agree to within about 0.01.
5. **02 Model evaluation.** Show accuracy and interval coverage by unseen surface. D50 is the hardest.
6. If asked about images: **05 SEM image model**. Pick a surface and press "Predict using this image set".

Backup 1: the browser version "Droplet Spread Predictor" (claude.ai artifact, 24 Sept 2026). Same trained baseline GP, no install; needs internet. Checked against the Python package on five impacts: identical β_max and interval to two decimals.
Backup 2: the older Streamlit dashboard (`streamlit run Overview.py`) has the same prediction on its Predict page.

## Likely questions (short, honest answers)
- **Did you do the experiments?** No. The impacts are a public dataset from Može et al., University of Ljubljana (*Data in Brief*, 2025). My contribution is testing on unseen surfaces, the surface descriptors, the models and the uncertainty analysis.
- **Hasn't someone already used a GP on this data?** Yes. Jereb et al. (*Biomimetics*, 2025) chose a GP with a random 80/20 split. I test on a surface the model has never seen, which is the harder and more useful question.
- **Why not deep learning?** I tested an FT-Transformer, a deep ensemble and an MLP on the same inputs. With 12 surfaces, all generalized worse than the GP on unseen surfaces.
- **Is this physics-informed?** Yes. The inputs are the dimensionless groups plus physically defined surface descriptors, and the target is log β_max. A scaling-law backbone was tested explicitly and gave no significant gain. The Laan law alone misses by about 11% on average.
- **Is the smooth plate really a blind test?** It was never used to train or choose a model, but I did look at its results during development. So I call it a held-out stress test, not a fully blind one.
- **Why only 62% coverage on the smooth plate?** The intervals are calibrated on textured, superhydrophobic surfaces. The smooth plate differs in wettability, which no input describes. The shortfall is mostly in water and the 20% and 60% mixtures; the viscous fluids stay at 96%. That is why the tool shows a warning for smooth surfaces.
- **Would it work on other materials?** Only within the texture family it was trained on. The CNN, for example, reads the smooth plate as φ ≈ 0.71, not 1.0. The next step is a wettability input.
- **How much does the surface matter?** Re and We carry most of the signal: mean |SHAP| of about 0.12–0.13 each against about 0.004 for φ and V_tex. Removing the surface inputs raises the unseen-surface error from 0.040 to 0.046 and the smooth-plate error from 0.059 to 0.069. It helps most on D50, the most extreme texture. With 12 surfaces that is a strong hint, not proof.
- **What would you do next?** Measure advancing and receding angles for every fluid–surface pair, let the noise level depend on viscosity, and add new surfaces with a test set held back before any tuning.
